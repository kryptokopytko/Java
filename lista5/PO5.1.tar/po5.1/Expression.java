import java.io.*;
public class Expression {
    char operation;
    int val;
    String name;
    Expression right;
    Expression left;
    public char get_operation() { return operation;}
    public int get_val() { return val;}
    public String get_name() { return name;}
    public Expression get_right() { return right;}
    public Expression get_left() { return left;}
    public void set_operation(char o) {operation = o;}
    public void set_val(int v ){val = v;}
    public void set_name(String n) {name = n;}
    public void set_right(Expression e) {right = e;}
    public void set_left(Expression e) {left = e;}
    
    public Expression (int n) {
	operation = '0';
	val = n;
	left = null;
	right = null;
	name = "";
    }
    public Expression (String Name) {
	operation = '0';
	val = 0;
	left = null;
        right = null; 
        name = Name;

    }
    public int evaluate (Expression current) {
        try {
        if (current.get_name() != "")
                throw new Exception("Nie mozna policzyc wartosci zmiennej");
        if (current.get_operation() == '0')
                return current.get_val();
        if (current.get_operation() == '+')
                return evaluate(current.get_left()) + evaluate(current.get_right());
        if (current.get_operation() == '*')
                return evaluate(current.get_left()) * evaluate(current.get_right());}
        catch (Exception e) {}
        return 0;
    }
    public String toString (Expression current) {
                if (current.get_name() != "")
                        return current.get_name();
                if (current.get_operation() == '0')
                        return Integer.toString(current.get_val());
                if (current.get_operation() == '+')
                        return '('+toString(current.get_left()) +") + ("+ toString(current.get_right()) + ')';
                if (current.get_operation() == '*')
                        return '('+toString(current.get_left()) +") * ("+ toString(current.get_right()) + ')';
                return "";
    }
    
}
