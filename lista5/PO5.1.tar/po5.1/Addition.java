public class Addition extends Expression {
    public Addition (Expression a, Expression b)
    {
		super(0);
		set_left(a);
		set_name("");
		set_operation('+');
		set_right(b);
		set_val(0);
		   
    }
}
