public class Program {
    public static void main (String[] args) {
	Expression A = new Expression(2);
	Expression B = new Expression(3);
	Expression C = new Addition (new Multiplication(A, B), new Addition(A, B));
	int a =C.evaluate(C);
	System.out.println(a);
	String napis = C.toString(C);
	System.out.println(napis);
    }
}
