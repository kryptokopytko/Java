public class OrderedList<T extends Comparable<T>> implements Comparable<T>{
    private Node<T> first;
    public Node<T> get_first() {return first;}
    public void set_first(Node<T> n) {n = first;}
    public OrderedList(T f)
    {
        first = new Node<T>(f);
    }
    @Override public int compareTo(T elem)
    {
        return first.get_val().compareTo(elem);
    }
    public void add_element(T elem)
    {
        Node<T> pom = first;
        while (pom.Is_greater(elem))
            pom = pom.get_next();
        if (pom.get_next() == null)
        {
            pom.set_next(new Node(elem));
            return;
        }
        Node pom2 = pom.get_next();
        pom.set_next(new Node(elem));
        pom = pom.get_next();
        pom.set_next(pom2);
    }
    public String toString()
    {
        String s = "";
        Node<T> pom = first;
        while (pom.get_next() != null)
        {
            s += String.valueOf(pom.get_val());
            s += ' ';
            pom = pom.get_next();
        }
        return s;
    }
}