class Program{
    public static void main(String[] args) {
       OrderedList<Integer> Lista = new OrderedList(6);
        for (int i = 43; i > 12; i--)
            Lista.add_element(i);
        String napis = Lista.toString();
        System.out.println(napis);
    }
}