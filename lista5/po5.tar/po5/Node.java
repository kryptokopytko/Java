public class Node <T extends Comparable<T>> {
    private T val;
    private Node<T> next;
    public T get_val() { return val;}
    public Node<T> get_next() {return next;}
    public void set_val(T value) { val = value;}
    public void set_next(Node<T> n) {next = n;}
    public Node(T value) {
        val = value;
        next = null;
    }
    public boolean Is_greater (T elem)
    {
        if ( val.compareTo(elem) < 1)
            return false;
        return true;
    }
}